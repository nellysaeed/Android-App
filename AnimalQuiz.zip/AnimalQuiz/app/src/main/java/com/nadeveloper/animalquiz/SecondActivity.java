package com.nadeveloper.animalquiz;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    RadioButton oneC;
    RadioButton twoD;
    RadioButton threeB;

    CheckBox checkBoxOne;
    CheckBox checkBoxTwo;
    CheckBox checkBoxThree;
    CheckBox checkBoxFour;
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hide the keyboard
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.activity_second);
    }

    public void submitAnswers(View view) {
        CharSequence resultsDisplay;
        int answer1_score;
        int answer2_score;
        int answer3_score;
        int answer4_score;
        int finalResult ;

        // Get user's name

        editText = findViewById(R.id.name_Field);
        String name = editText.getText().toString();

        // Check if a user name is written
        if (editText.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please write down your name.", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        // Question 1 - Correct Answer is #C

        Boolean answerOne;
        oneC =  findViewById(R.id.oneC);
        answerOne = oneC.isChecked();
        if (answerOne) {
            answer1_score = 1;
        } else {
            answer1_score = 0;
        }

        // Question 2- Correct Answer is #D

        Boolean answerTwo;
        twoD = findViewById(R.id.twoD);
        answerTwo = twoD.isChecked();
        if (answerTwo) {
            answer2_score = 1;
        } else {
            answer2_score = 0;
        }

        // Question 3 - Correct Answer is #B

        Boolean answerThree;
        threeB = findViewById(R.id.threeB);
        answerThree = threeB.isChecked();
        if (answerThree) {
            answer3_score = 1;
        } else {
            answer3_score = 0;
        }

        // Question 4 - Correct Answer is #A and #C

        Boolean answer4_choice1;
        Boolean answer4_choice2;
        Boolean answer4_choice3;
        Boolean answer4_choice4;
        checkBoxOne =  this.findViewById(R.id.checkBoxOne);
        checkBoxTwo =  this.findViewById(R.id.checkBoxTwo);
        checkBoxThree = this.findViewById(R.id.checkBoxThree);
        checkBoxFour =  this.findViewById(R.id.checkBoxFour);
        answer4_choice1 = checkBoxOne.isChecked();
        answer4_choice2 = checkBoxTwo.isChecked();
        answer4_choice3 = checkBoxThree.isChecked();
        answer4_choice4 = checkBoxFour.isChecked();
        if (answer4_choice1 && !answer4_choice2 && answer4_choice3 && !answer4_choice4) {
            answer4_score = 1;
        } else {
            answer4_score = 0;
        }

        //------------------------------------------------------------------------------------------
        // Final Score
        //------------------------------------------------------------------------------------------
        finalResult = answer1_score + answer2_score + answer3_score + answer4_score;

        if (finalResult == 4) {
            resultsDisplay =  name   + "\n Perfect! You scored 4 out of 4" ;

        } else {
            resultsDisplay =  name + "\n Please Try again. You scored " + finalResult + " out of 4";
        }


        Context context = getApplicationContext();
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, resultsDisplay, duration);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }
}
